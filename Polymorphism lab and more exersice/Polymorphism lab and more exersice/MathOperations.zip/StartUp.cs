﻿namespace Operations
{

    public class StartUp
    {

        static void Main(string[] args)
        {
            MathOperations operations = new MathOperations();
            Console.WriteLine(operations.Add(2,6));
        }


    }
}
